package com.company;

public class Heroes {
    private String point;
    private String type;

    public Heroes(){}
    public Heroes(String point, String type){
        this.point = point;
        this.type = type;
    }
    public String getPoint() {
        return point;
    }

    public String getType() {
        return type;
    }
}
