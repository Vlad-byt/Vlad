package com.company;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.*;

public class Main {
    private List <Player> playerList;
    private List <Heroes> heroesList;
    private List <Heroes> randomHeroes;
    private Scanner console;
    private String name;
    private Heroes getHeroes;

    public static void main(String[] args) {
        Main game = new Main();
        game.createPlayer();
        game.random();
        game.play();
    }

    public Main(){
        playerList = new ArrayList<Player>();
        heroesList = new ArrayList<Heroes>();
        randomHeroes = new ArrayList<Heroes>();
        console = new Scanner(System.in);

        String[] points = {"1","2","3","4","5","6","7","8","9","10","Master","Wizard","Elemental","God"};
        String [] types = {"Water", "Freez", "Wind", "Fire"};

        for (String point : points){
            for (String type : types){
                Heroes hero = new Heroes(point, type);
                heroesList.add(hero);
            }
        }
    }

    public void createPlayer(){
        playerList.add(new Player("Computer"));
        System.out.println ("  ! Игрок !  ");

        for (int i = 0; i<3; i++){
            System.out.println (String.format("Пожалуйста, введите название %d команды: ", i+1));
            name = console.next();
            playerList.add(new Player(name));
        }
        for (Player player : playerList){
            System.out.println ("Добро пожаловать, игрок: " + player.getName ());
        }
    }

    public void random(){
        Random random = new Random();
        Heroes hero = new Heroes();

        for (int i = 0; i<heroesList.size(); i++){
            int position = random.nextInt(heroesList.size());
            hero = heroesList.get(position);
            randomHeroes.add(hero);
        }
    }

    public void play() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                getHeroes = randomHeroes.get(i * 3 + j);
                playerList.get(j).getHeroes().add(getHeroes);
            }
        }

        System.out.println("  !  Карты ваших команд !  ");
        for (int i = 1; i < 4; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.println(playerList.get(i).getName() + ": " + playerList.get(i).getHeroes().get(j).getType() + " " + playerList.get(i).getHeroes().get(j).getPoint());
            }
        }
            System.out.println("  !  Выберите команду для сражения, нажав 1, 2 или 3 !  ");
            int conn = console.nextInt();

            System.out.println("  ! Результат !  ");
            int player1 = 0;
            int player2 = 0;
            for (int i = 0; i < 3; i++) {
                player1 += heroesList.indexOf(playerList.get(0).getHeroes().get(i)) + 1;
                player2 += heroesList.indexOf(playerList.get(conn).getHeroes().get(i)) + 1;
            }

            for (int j = 0; j < 3; j++) {
                System.out.println(playerList.get(0).getName() + ": " + playerList.get(0).getHeroes().get(j).getType() + " " + playerList.get(0).getHeroes().get(j).getPoint());
            }
            for (int j = 0; j < 3; j++) {
                System.out.println(playerList.get(conn).getName() + ": " + playerList.get(conn).getHeroes().get(j).getType() + " " + playerList.get(conn).getHeroes().get(j).getPoint());
            }

            if (player1 > player2) {
                System.out.println("Команда: " + playerList.get(0).getName() + " победила!");

            } else if (player1 < player2) {
                System.out.println("Команда: " + playerList.get(conn).getName() + " победила!");
            } else {
                System.out.println("Ничья!");
            }
        }
}
