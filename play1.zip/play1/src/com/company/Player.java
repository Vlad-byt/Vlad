package com.company;

import java.util.ArrayList;
import java.util.List;

public class Player {
    private String name;
    private List<Heroes> heroes;

    public Player(String name){
        this.name = name;
        this.heroes = new ArrayList<Heroes>();
    }

    public String getName() {
        return name;
    }

    public List<Heroes> getHeroes() {
        return heroes;
    }
}

